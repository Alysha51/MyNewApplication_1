package com.example.adminapp;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.GridView;
import android.widget.ListView;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.viewpager.widget.ViewPager;

import java.util.ArrayList;


public class CategorySelectorActivity extends AppCompatActivity {
    private ArrayList<Category> categories;
    private GridView gridView;

    private TextView listViewOption;
    private CategoryAdapter categoryAdapter;
    private ArrayList<Item> allItems;
    private ArrayList<Item> selectedItems;
    private ListView listView;

        @Override
        protected void onCreate(Bundle savedInstanceState) {
            super.onCreate(savedInstanceState);
            setContentView(R.layout.activity_category_selector);

            listViewOption = findViewById(R.id.listViewOption);

            ViewPager viewPager = findViewById(R.id.viewPager);
            SlideAdapter slideAdapter = new SlideAdapter(this);
            viewPager.setAdapter(slideAdapter);

//            categories = new ArrayList<>();
//            categories.add(new Category(R.drawable.ic_category, "Category 1"));
//            categories.add(new Category(R.drawable.ic_category, "Category 2"));
//            categories.add(new Category(R.drawable.ic_category, "Category 3"));
//            categories.add(new Category(R.drawable.ic_category, "Category 4"));

//            allItems = new ArrayList<>();
//            allItems.add(new Item("Item 1", "Category 1"));
//            allItems.add(new Item("Item 2", "Category 2"));
//            allItems.add(new Item("Item 3", "Category 1"));
            // ... Add more items

//            selectedItems = new ArrayList<>();
//
//            listViewOption = findViewById(R.id.listViewOption);
//            categoryAdapter = new CategoryAdapter(this, categories);
//            listView.setAdapter(categoryAdapter);


            // Initialize Firebase Cloud Messaging here

            // Subscribe to topics based on selected categories
            // This code should be triggered when the user selects categories
//             for (Category category : categories) {
//                 if (category.isSelected()) {
//                     FirebaseMessaging.getInstance().subscribeToTopic(category.getName());
//                 }
//             }

            // Handle FCM notifications
            // Implement your logic to handle incoming FCM notifications and display them in the app
            // When you receive a notification, you can extract the category from the notification payload
            // and filter the items accordingly.
            // Display the filtered items in the list view.
            // Be sure to update the UI on the main thread using runOnUiThread.

            categories = new ArrayList<>();
            categories.add(new Category(R.drawable.ic_category, "Category 1"));
            categories.add(new Category(R.drawable.ic_category, "Category 2"));
            categories.add(new Category(R.drawable.ic_category, "Category 3"));
            categories.add(new Category(R.drawable.ic_category, "Category 4"));
            categories.add(new Category(R.drawable.ic_category, "Category 5"));
            categories.add(new Category(R.drawable.ic_category, "Category 6"));

            gridView = findViewById(R.id.categoryGridView);
            categoryAdapter = new CategoryAdapter(this, categories);
            gridView.setAdapter(categoryAdapter);

            // Start ListViewActivity when "List View" option is clicked

            Button selectAllButton = findViewById(R.id.selectAllButton);
            selectAllButton.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    for (Category category : categories) {
                        category.setSelected(true);
                    }
                    categoryAdapter.notifyDataSetChanged();
                }
            });

            Button selectButton = findViewById(R.id.selectButton);
            selectButton.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    // Handle selected categories

                    // Inside selectButton click listener
                    // ... (Previous code)

// Filter items based on selected categories
//                    selectedItems.clear(); // Clear the previous selected items
//                    for (Item item : allItems) {
//                        for (Category selectedCategory : selectedCategories) {
//                            if (item.getCategory().equals(selectedCategory.getName())) {
//                                selectedItems.add(item);
//                                break; // Once the item is added, move to the next item
//                            }
//                        }
//                    }

// Now the selectedItems list contains items related to selected categories

// Update the list view to display the filtered items
//                    ArrayAdapter<Item> itemsAdapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, selectedItems);
//                    listView.setAdapter(itemsAdapter);



                    ArrayList<Category> selectedCategories = new ArrayList<>();
                    for (Category category : categories) {
                        if (category.isSelected()) {
                            selectedCategories.add(category);
                        }
                    }

                    listViewOption.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            // Add a log message to verify the click event
                            Log.d("CategorySelectorActivity", "List View option clicked");

                            // Start ListViewActivity when "List View" option is clicked
                            Intent intent = new Intent(CategorySelectorActivity.this, ListViewActivity.class);
                            startActivity(intent);
                        }
                    });
// Now the selectedCategories list contains the selected categories
                    // Handle selected categories
                }
            });
        }

}

